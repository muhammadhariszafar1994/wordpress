<?php return array('dependencies' => array('react', 'wp-server-side-render'), 'version' => 'f2b790f488458ee6fc3e');
