/**
 * Import LearnDash Achievement blocks
 */
import './ld-my-achievements';
import './ld-achievements-leaderboard';
